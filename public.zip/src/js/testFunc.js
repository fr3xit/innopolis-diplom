export default function test() {
	alert('Тут должна быть функция, но ее почему то тут нет!');
}
